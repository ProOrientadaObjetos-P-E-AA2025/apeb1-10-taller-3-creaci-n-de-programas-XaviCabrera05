package terreno;

public class TerrenoApp {
    public static void main(String[] args) {
        // TODO: Implement logic for Ejercicio1_Terreno
    }
}
