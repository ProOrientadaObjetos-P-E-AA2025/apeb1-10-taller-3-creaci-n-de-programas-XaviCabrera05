package celular;

public class CelularApp {
    public static void main(String[] args) {
        // TODO: Implement logic for Ejercicio4_EquipoCelular
    }
}
