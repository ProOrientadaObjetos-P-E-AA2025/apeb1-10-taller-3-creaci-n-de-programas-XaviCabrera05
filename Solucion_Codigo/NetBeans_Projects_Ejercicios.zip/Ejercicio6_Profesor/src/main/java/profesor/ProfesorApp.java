package profesor;

public class ProfesorApp {
    public static void main(String[] args) {
        // TODO: Implement logic for Ejercicio6_Profesor
    }
}
