package automovil;

public class AutomovilApp {
    public static void main(String[] args) {
        // TODO: Implement logic for Ejercicio7_Automovil
    }
}
