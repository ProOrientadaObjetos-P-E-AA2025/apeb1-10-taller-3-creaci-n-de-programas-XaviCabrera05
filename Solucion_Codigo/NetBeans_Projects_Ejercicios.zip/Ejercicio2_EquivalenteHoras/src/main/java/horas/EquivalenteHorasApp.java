package horas;

public class EquivalenteHorasApp {
    public static void main(String[] args) {
        // TODO: Implement logic for Ejercicio2_EquivalenteHoras
    }
}
