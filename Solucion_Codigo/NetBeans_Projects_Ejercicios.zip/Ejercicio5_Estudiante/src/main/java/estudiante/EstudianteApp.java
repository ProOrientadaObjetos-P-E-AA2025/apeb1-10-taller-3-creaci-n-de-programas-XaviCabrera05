package estudiante;

public class EstudianteApp {
    public static void main(String[] args) {
        // TODO: Implement logic for Ejercicio5_Estudiante
    }
}
