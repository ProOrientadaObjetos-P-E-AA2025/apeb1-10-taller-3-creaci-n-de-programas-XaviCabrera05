package institucion;

public class InstitucionApp {
    public static void main(String[] args) {
        // TODO: Implement logic for Ejercicio3_InstitucionEducativa
    }
}
